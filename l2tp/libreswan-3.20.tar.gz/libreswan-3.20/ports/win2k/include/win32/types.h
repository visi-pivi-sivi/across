
#include <cygwin/types.h>
#include <sys/types.h>
#include <asm/types.h>
#include <stdint.h>

#ifndef AF_INET6
#define AF_INET6  23
#endif

#ifndef PF_INET6
#define PF_INET6  23
#endif
